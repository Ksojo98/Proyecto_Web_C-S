require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');

const mainRoutes = require('./routes/mainRoutes');
const userRoutes = require('./routes/userRoutes');
const apiRoutes = require('./routes/apiRoutes');
const contactRoute = require('./routes/contact');

const app = express();
const PORT = process.env.PORT || 3001;

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir archivos estáticos (HTML, CSS, imágenes, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// ✅ Ruta para recibir reseñas y redirigir al popup
app.post('/api/reviews', (req, res) => {
  const { nombre, comentario, estrellas } = req.body;

  console.log('Reseña recibida:', {
    nombre,
    comentario,
    estrellas
  });

  // Aquí podrías guardar en una base de datos si deseas

  // Redirigir a la página que activa el modal
  res.redirect('/resena_exitosa.html');
});

// Rutas principales
app.use('/', mainRoutes);
app.use('/', userRoutes);
app.use('/api', apiRoutes);
app.use(contactRoute);

// Manejo de errores
app.use((req, res) => {
  res.status(404).sendFile(path.join(__dirname, 'views', '404.html'));
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Error interno del servidor');
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`\n=================================`);
  console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
  console.log(`=================================\n`);
});

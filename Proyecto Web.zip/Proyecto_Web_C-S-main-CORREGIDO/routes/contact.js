const express = require('express');
const router = express.Router();

router.post('/api/contact', (req, res) => {
    const { name, email, message } = req.body;

    // Aquí podrías guardar en base de datos o enviar un correo
    console.log("Mensaje recibido:");
    console.log("Nombre:", name);
    console.log("Correo:", email);
    console.log("Mensaje:", message);

    res.send("Mensaje recibido");
});

module.exports = router;

const express = require('express');
const router = express.Router();

// Login
router.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    console.log("Login:", { username, password });

    // Validación temporal (sustituí esto con validación real con base de datos)
    if (username === 'admin' && password === '123') {
        res.json({ success: true });
    } else {
        res.status(401).json({ success: false, message: 'Credenciales inválidas' });
    }
});

// Registro
router.post('/api/register', (req, res) => {
    const { name, email, password } = req.body;
    console.log("Register:", { name, email, password });

    // Registro simulado
    res.json({ success: true, message: 'Registro exitoso' });
});

module.exports = router;
